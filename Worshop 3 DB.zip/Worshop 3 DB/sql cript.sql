-- Crear la base de datos YouTubeDB si no existe
CREATE DATABASE IF NOT EXISTS YouTubeDB;

-- Usar la base de datos YouTubeDB
USE YouTubeDB;

-- Crear la tabla Channel
CREATE TABLE IF NOT EXISTS Channel (
    ChannelID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Subscribers INT UNSIGNED,
    Country VARCHAR(100),
    UNIQUE (Name)
);

-- Insertar datos de ejemplo en la tabla Channel
INSERT INTO Channel (Name, Subscribers, Country) VALUES
('Channel A', 1000000, 'United States'),
('Channel B', 500000, 'United Kingdom'),
('Channel C', 2000000, 'Canada');

-- Crear la tabla User
CREATE TABLE IF NOT EXISTS User (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Alias VARCHAR(100) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    UNIQUE (Alias)
);

-- Insertar datos de ejemplo en la tabla User
INSERT INTO User (Name, Alias, Password) VALUES
('User 1', 'user1', 'password1'),
('User 2', 'user2', 'password2'),
('User 3', 'user3', 'password3');

-- Crear la tabla Video
CREATE TABLE IF NOT EXISTS Video (
    VideoID INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(255) NOT NULL,
    Views INT UNSIGNED,
    Likes INT UNSIGNED,
    Dislikes INT UNSIGNED,
    ChannelID INT,
    FOREIGN KEY (ChannelID) REFERENCES Channel(ChannelID)
);

-- Insertar datos de ejemplo en la tabla Video
INSERT INTO Video (Title, Views, Likes, Dislikes, ChannelID) VALUES
('Video 1', 10000, 500, 20, 1),
('Video 2', 5000, 200, 10, 2),
('Video 3', 20000, 1000, 50, 3);

-- Crear la tabla Playlist
CREATE TABLE IF NOT EXISTS Playlist (
    PlaylistID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    OwnerID INT,
    ChannelID INT,
    FOREIGN KEY (OwnerID) REFERENCES User(UserID),
    FOREIGN KEY (ChannelID) REFERENCES Channel(ChannelID)
);

-- Insertar datos de ejemplo en la tabla Playlist
INSERT INTO Playlist (Name, OwnerID, ChannelID) VALUES
('Playlist 1', 1, 1),
('Playlist 2', 2, 2),
('Playlist 3', 3, 3);
